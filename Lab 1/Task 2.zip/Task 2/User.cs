﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2
{
    public class User
    {
        public List<Playlist> playlists = new List<Playlist>();


        public void Play_Audio(Audio a)
        {
            Console.WriteLine(a.title + " Playing");
        }

        public void Pause_Audio(Audio a)
        {
            Console.WriteLine(a.title + " Paused");
        }

        public void Stop_Audio(Audio a)
        {
            Console.WriteLine(a.title + " Stopped");
        }        

        public void Create_Playlist(Playlist p)
        {
            playlists.Add(p);
            Console.WriteLine(p+ " Added as a playlist");
        }

        public void Add_Audio_to_Playlist(Audio a, Playlist p)
        {
            p.audios.Add(a);
            Console.WriteLine(a + " Added to the playlist " +p);
        }

        public void Play_AlltheAudio_ofa_Playlist(Playlist p)
        {
            foreach (Audio a in p.audios)
            {
                Console.WriteLine(a);
            }
        }
    }
}
